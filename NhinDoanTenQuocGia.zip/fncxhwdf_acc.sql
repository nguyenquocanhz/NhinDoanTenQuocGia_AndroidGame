-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th4 02, 2024 lúc 07:08 PM
-- Phiên bản máy phục vụ: 5.7.41-cll-lve
-- Phiên bản PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `fncxhwdf_acc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `api_key_tool`
--

CREATE TABLE `api_key_tool` (
  `id` int(11) NOT NULL,
  `api_key` text CHARACTER SET utf8mb4,
  `ip` text CHARACTER SET utf8mb4,
  `status` text CHARACTER SET utf8mb4
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `api_key_tool`
--

INSERT INTO `api_key_tool` (`id`, `api_key`, `ip`, `status`) VALUES
(1, '0397426841', NULL, 'active'),
(2, '0945946021', NULL, 'active');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `stk` text NOT NULL,
  `name` text NOT NULL,
  `bank_name` text NOT NULL,
  `chi_nhanh` text NOT NULL,
  `logo` text,
  `ghichu` text,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `bank`
--

INSERT INTO `bank` (`id`, `stk`, `name`, `bank_name`, `chi_nhanh`, `logo`, `ghichu`, `create_time`) VALUES
(3, '0397426841', 'Nguyễn Quốc Anh', 'MOMO', '', 'https://i.imgur.com/uW9DDAw.png', '', '2023-02-06 18:58:58'),
(4, '0397426841', 'Nguyễn Quốc Anh', 'Vietcombank', '', 'https://source.nguyenquocanh-dev.site/assets/storage/images/upload_VETFO2YU79SJ.png', '', '2023-02-07 10:24:38'),
(5, '0397426841', 'Nguyễn Quốc Anh', 'Viettelpay', '', 'https://source.nguyenquocanh-dev.site/assets/storage/images/upload_VETFO2YU79SJ.png', '', '2023-02-07 10:28:12');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bank_auto`
--

CREATE TABLE `bank_auto` (
  `id` int(11) NOT NULL,
  `tid` varchar(64) DEFAULT NULL,
  `description` text,
  `amount` int(11) DEFAULT '0',
  `cusum_balance` int(11) DEFAULT '0',
  `time` datetime DEFAULT NULL,
  `bank_sub_acc_id` varchar(64) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `deletedate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `banquyen`
--

CREATE TABLE `banquyen` (
  `id` int(10) NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `devices` text CHARACTER SET utf8mb4,
  `lincese_key` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `created_At` timestamp NULL DEFAULT NULL,
  `exprire_At` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `banquyen`
--

INSERT INTO `banquyen` (`id`, `ip`, `devices`, `lincese_key`, `created_At`, `exprire_At`) VALUES
(1, NULL, 'X540LA', '0397426841', '2023-08-01 16:53:05', '2023-09-01 17:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `username` varchar(32) NOT NULL,
  `loaithe` varchar(32) NOT NULL,
  `menhgia` int(11) NOT NULL,
  `thucnhan` int(11) DEFAULT '0',
  `seri` text NOT NULL,
  `pin` text NOT NULL,
  `createdate` datetime NOT NULL,
  `status` varchar(32) NOT NULL,
  `note` text NOT NULL,
  `deletedate` varchar(255) DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `cards`
--

INSERT INTO `cards` (`id`, `code`, `username`, `loaithe`, `menhgia`, `thucnhan`, `seri`, `pin`, `createdate`, `status`, `note`, `deletedate`, `ip`) VALUES
(1, '17439', 'Guest', 'VIETTEL', 50000, 0, '10009679315651', '980161937524390', '2023-06-03 22:23:01', 'thanhcong', '', NULL, '118.68.85.35'),
(2, '95012', 'Guest', 'VIETTEL', 100000, 0, '10009401748376', '119304647363755', '2023-06-05 10:44:21', 'thanhcong', '', NULL, '118.68.85.35'),
(3, '96129', 'Guest', 'VIETTEL', 100000, 0, '10009401748365', '119304647363787', '2023-06-05 10:45:09', 'thanhcong', '', NULL, '118.68.85.35'),
(4, '61906', 'Guest', 'VIETTEL', 100000, 0, '10009721217458', '980161937567648', '2023-06-05 10:52:11', 'thatbai', '', NULL, '118.68.85.35'),
(5, '36358', 'Guest', 'VIETTEL', 100000, 0, '10009679315077', '119304647363416', '2023-06-05 11:39:33', 'thanhcong', '', NULL, '118.68.85.35'),
(6, '32868', 'Guest', 'VIETTEL', 100000, 0, '10009721213222', '119304647363886', '2023-06-05 11:44:03', 'thatbai', '', NULL, '118.68.85.35'),
(7, '38430', 'Guest', 'VIETTEL', 100000, 0, '10009401748344', '786304647363796', '2023-06-05 11:53:36', 'thatbai', '', NULL, '118.68.85.35'),
(8, '73604', 'Guest', 'VIETTEL', 50000, 0, '10009789412064', '018016818525396', '2023-06-19 09:24:41', 'xuly', '', NULL, '27.69.227.227'),
(9, '88501', 'Guest', 'VINAPHONE', 200000, 0, '10008848626780', '35820349394949', '2023-07-03 19:37:45', 'xuly', '', NULL, '116.97.109.123'),
(10, '38511', 'Guest', 'VIETTEL', 50000, 0, '10009938641306', '514541170831383', '2023-07-10 16:07:30', 'xuly', '', NULL, '2001:ee0:49c9:6a90:14fd:631b:26b2:f329'),
(11, '75915', 'Guest', 'VIETTEL', 50000, 0, '10009902520183', '610554999555430', '2023-07-31 14:20:45', 'xuly', '', NULL, '2402:800:6131:6321:5d64:df3b:23bc:6cfb'),
(12, '41677', 'Guest', 'VIETTEL', 100000, 0, '20006874598346', '554888634265987', '2023-08-22 14:42:07', 'xuly', '', NULL, '113.168.149.255'),
(13, '62415', 'Guest', 'VIETTEL', 200000, 0, '10003426116575', '324156438653746', '2023-08-22 20:20:40', 'xuly', '', NULL, '113.168.149.255'),
(14, '81153', 'Guest', 'VIETTEL', 20000, 0, '10009721245666', '090161937544588', '2023-08-23 10:21:38', 'xuly', '', NULL, '118.68.84.191'),
(15, '16149', 'Guest', 'VIETTEL', 50000, 0, '10010026225553', '810037978548675', '2023-10-22 20:36:05', 'thatbai', '', NULL, '2402:800:6195:ec12:7deb:1fbb:94e4:b93'),
(16, '99206', 'Guest', 'VIETTEL', 20000, 0, '10010037012248', '615121974381283', '2023-12-23 19:02:42', 'thatbai', '', NULL, '2001:ee0:437b:2860:b551:e7f:37ab:c863'),
(17, '71216', 'Guest', 'VIETTEL', 50000, 0, '10018544499013', '511785153962904', '2024-02-24 23:04:37', 'thatbai', '', NULL, '2405:4803:db46:e1a0:3821:de85:e8bb:2c66'),
(18, '46003', 'Guest', 'VIETTEL', 50000, 0, '10009721212254', '810957067250584', '2024-02-29 21:07:09', 'thatbai', '', NULL, '1.53.27.167'),
(19, '67073', 'Guest', 'VIETTEL', 50000, 0, '10212122540097', '819270058506745', '2024-03-06 00:52:16', 'thatbai', '', NULL, '1.53.27.167'),
(20, '15822', 'Guest', 'VIETTEL', 50000, 50000, '10010452716618', '517211812213895', '2024-03-06 11:59:52', 'thanhcong', '', NULL, '2402:800:6198:7529:bcca:f399:23a8:8286'),
(21, '84806', 'Guest', 'VIETTEL', 50000, 0, '10009722542121', '857132622774767', '2024-03-06 12:27:52', 'thatbai', '', NULL, '2405:4803:db46:e1a0:8013:410a:d2d1:d4ae'),
(22, '42432', 'Guest', 'VIETTEL', 50000, 0, '10009122547212', '816745050927085', '2024-03-06 16:10:41', 'thatbai', '', NULL, '1.53.27.167'),
(23, '86319', 'Guest', 'VINAPHONE', 50000, 0, '39462066549824', '38000514086047', '2024-03-10 19:05:35', 'thatbai', '', NULL, '113.190.253.181'),
(24, '87455', 'Guest', 'VIETTEL', 50000, 50000, '10010476218323', '719113392124367', '2024-03-16 18:07:10', 'thanhcong', '', NULL, '42.113.252.211');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `img` longtext CHARACTER SET utf8mb4,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `quanlity_sell` int(50) NOT NULL DEFAULT '0',
  `quanlity_orders` int(50) NOT NULL DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `display` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`id`, `img`, `name`, `description`, `quanlity_sell`, `quanlity_orders`, `create_time`, `display`) VALUES
(1, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy chủ FPT Hà Nội\r\n', 'Không giới hạn', 0, 0, '2023-02-03 18:20:33', 'SHOW'),
(2, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy Chủ FPT HCM', 'Không giới hạn', 0, 0, '2023-02-03 18:26:43', 'SHOW'),
(3, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy Chủ FPT HUẾ', 'Không giới hạn', 0, 0, '2023-02-03 18:33:33', 'SHOW'),
(4, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy Chủ FPT HCM3', 'Không giới hạn', 0, 0, '2023-02-03 19:26:43', 'SHOW'),
(5, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy Chủ FPT HCM1', 'Không giới hạn', 0, 0, '2023-02-03 18:45:43', 'SHOW'),
(6, 'https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/vn.svg', 'Cụm Máy Chủ FPT HCM2', 'Không giới hạn', 0, 0, '2023-02-03 18:50:43', 'SHOW');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `display` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `city`
--

INSERT INTO `city` (`id`, `country_id`, `name`, `update_time`, `display`) VALUES
(2, 1, 'Hồ Chí Minh', '2023-02-04 05:10:30', 'SHOW'),
(3, NULL, 'Hà Nội', '2023-02-09 18:40:04', 'SHOW');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cloud`
--

CREATE TABLE `cloud` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `img` longtext CHARACTER SET utf8mb4,
  `ipv4` int(11) NOT NULL DEFAULT '1',
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `money` int(50) NOT NULL DEFAULT '0',
  `COUNTRY` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `RAM` int(50) DEFAULT '4',
  `CPU` int(50) DEFAULT '1',
  `SSD` int(50) DEFAULT '20',
  `OS` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `display` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `cloud`
--

INSERT INTO `cloud` (`id`, `category_id`, `img`, `ipv4`, `name`, `money`, `COUNTRY`, `RAM`, `CPU`, `SSD`, `OS`, `display`) VALUES
(1, 1, 'assets/img/cloud.png', 1, 'CLOUD A', 20000, 'US', 1, 1, 12, 'LINUX', 'SHOW'),
(2, 1, 'assets/img/cloud.png', 1, 'CLOUD B', 250000, 'Hồ Chí Minh', 2, 2, 20, 'Windows Server 2012', 'SHOW');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `display` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `country`
--

INSERT INTO `country` (`id`, `name`, `update_time`, `display`) VALUES
(1, 'Việt Nam', '2023-02-04 05:08:20', 'SHOW');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dongtien`
--

CREATE TABLE `dongtien` (
  `id` int(11) NOT NULL,
  `sotientruoc` int(11) DEFAULT NULL,
  `sotienthaydoi` int(11) DEFAULT NULL,
  `sotiensau` int(11) DEFAULT NULL,
  `thoigian` datetime DEFAULT NULL,
  `noidung` text,
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `dongtien`
--

INSERT INTO `dongtien` (`id`, `sotientruoc`, `sotienthaydoi`, `sotiensau`, `thoigian`, `noidung`, `username`) VALUES
(1, 150000, 50000, 200000, '2023-02-04 22:57:25', 'Admin cộng tiền ()', 'nguyenquocanhdz'),
(2, 200000, 134000, 66000, '2023-02-05 00:51:48', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(3, 0, 5000000, 5000000, '2023-02-05 10:39:36', 'Admin cộng tiền (Admin)', 'hoangkhoi'),
(4, 66000, 5000000, 5066000, '2023-02-05 10:44:01', 'Admin cộng tiền (Admin)', 'nguyenquocanhdz'),
(5, 5066000, -402000, 4664000, '2023-02-05 10:46:00', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(6, 5000000, -134000, 4866000, '2023-02-05 11:38:01', 'Mua Cloud VPS', 'hoangkhoi'),
(7, 500000, -402000, 98000, '2023-02-05 20:24:20', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(8, 98000, 50000000, 50098000, '2023-02-05 22:20:02', 'Admin cộng tiền ()', 'nguyenquocanhdz'),
(9, 50098000, -402000, 49696000, '2023-02-05 22:20:38', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(10, 49696000, -49696000, 0, '2023-02-05 22:26:12', 'Admin thay đổi số dư ', 'nguyenquocanhdz'),
(11, 49696000, -49696000, 0, '2023-02-05 22:29:14', 'Admin thay đổi số dư ', 'nguyenquocanhdz'),
(12, 4866000, -134000, 4732000, '2023-02-05 23:44:35', 'Mua Cloud VPS', 'hoangkhoi'),
(13, 0, 500000, 500000, '2023-02-06 09:48:30', 'Admin cộng tiền ()', 'nguyenquocanhdz'),
(14, 500000, -134000, 366000, '2023-02-06 09:48:52', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(15, 4732000, -134000, 4598000, '2023-02-06 10:25:19', 'Mua Cloud VPS', 'hoangkhoi'),
(16, 366000, -107200, 232000, '2023-02-06 23:13:32', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(17, 258800, -107200, 124800, '2023-02-06 23:18:10', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(18, 151600, -16000, 131600, '2023-02-07 17:36:43', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(19, 135600, -16000, 115600, '2023-02-08 13:00:11', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(20, 119600, -16000, 99600, '2023-02-08 13:29:52', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(21, 103600, -16000, 83600, '2023-02-09 01:58:37', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(22, 87600, -16000, 67600, '2023-02-10 22:36:35', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(23, 71600, -48000, 11600, '2023-02-10 22:40:37', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(24, 23600, 5000000, 5023600, '2023-02-10 22:42:14', 'Admin cộng tiền ()', 'nguyenquocanhdz'),
(25, 5023600, -16000, 5003600, '2023-02-10 22:42:38', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(26, 5007600, -48000, 4947600, '2023-02-10 22:43:53', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(27, 4959600, -48000, 4899600, '2023-02-11 02:23:31', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(28, 4911600, -600000, 4161600, '2023-02-11 02:26:48', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(29, 4311600, -16000, 4291600, '2023-02-11 02:29:27', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(30, 4295600, -16000, 4275600, '2023-02-11 02:32:45', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(31, 4279600, -16000, 4259600, '2023-02-11 02:41:37', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(32, 4263600, -16000, 4243600, '2023-02-11 02:44:19', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(33, 4247600, -48000, 4187600, '2023-02-11 02:45:41', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(34, 4199600, -48000, 4139600, '2023-02-11 03:01:06', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(35, 4151600, -16000, 4131600, '2023-02-11 03:02:22', 'Mua Cloud VPS', 'nguyenquocanhdz'),
(36, 4135600, -16000, 4115600, '2023-02-14 00:50:04', 'Mua Cloud VPS', 'nguyenquocanhdz');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `money` int(50) NOT NULL DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `display` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `napthe`
--

CREATE TABLE `napthe` (
  `id` int(11) NOT NULL,
  `id_game` text CHARACTER SET utf8mb4,
  `code` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `serial` text CHARACTER SET utf8mb4 NOT NULL,
  `amount` int(20) NOT NULL,
  `telco` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `request_id` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `thoigian` text CHARACTER SET utf8mb4
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `napthe`
--

INSERT INTO `napthe` (`id`, `id_game`, `code`, `serial`, `amount`, `telco`, `request_id`, `status`, `thoigian`) VALUES
(1, '741112254', NULL, '10009721219024', 50000, NULL, NULL, 'xuly', '2023/05/10 16:56:54'),
(2, '74221444', NULL, '10009679315037', 50000, NULL, NULL, 'xuly', '2023/05/11 00:36:14'),
(3, '445365345', NULL, '097975000046802', 50000, NULL, NULL, 'xuly', '2023/05/11 14:33:42');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `options`
--

INSERT INTO `options` (`id`, `name`, `value`) VALUES
(1, 'tenweb', 'CLOUD'),
(2, 'email_admin', 'nguyenquocanh.dev@gmail.com'),
(3, 'hotline', '0397426841'),
(4, 'apikey', NULL),
(5, 'mota', 'CLOUD'),
(6, 'favicon', '/image/icon.ico?v=2'),
(7, 'anhbia', '/image/nroblue.png'),
(8, 'thongbao', 'Các bạn vui lòng cập nhật id telegram để có lấy lại password nếu quên'),
(9, 'noidung_naptien', 'naptien_'),
(10, 'html_footer', ''),
(11, 'text_left_footer', ''),
(12, 'text_center_footer', ''),
(13, 'block_f12', 'OFF'),
(14, 'ck_card', '15'),
(15, 'license_key', ''),
(16, 'logo_dark', ''),
(17, 'background', ''),
(18, 'status_demo', 'OFF'),
(19, 'status_napbank', 'OFF'),
(20, 'api_bank', ''),
(21, 'stk_bank', ''),
(22, 'mk_bank', ''),
(23, 'api_momo', ''),
(24, 'luuy_napbank', ''),
(25, 'ck_bank', '20'),
(26, 'baotri', 'OFF'),
(27, 'email', 'cuibapvh4@gmail.com'),
(28, 'pass_email', 'sgfxgcrrgoyjvlgi'),
(29, 'telegram', ''),
(30, 'zalo', ''),
(31, 'facebook', '//fb.com/anhnguyendz'),
(32, 'dieukhoan', '<h2 style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; font-size: 28px; font-weight: 700; margin-right: 0px; margin-bottom: 13.2px; margin-left: 0px; font-family: Roboto, sans-serif; word-break: break-word; padding-top: 10.8px; color: rgb(36, 41, 46); line-height: 1.4;\"><span style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; word-break: break-word;\">1. Trách nhiệm của khách hàng</span></h2><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.1   Khách hàng chịu trách nhiệm trước pháp luật về toàn bộ dữ liệu khi sử dụng dịch vụ thuê hạ tầng máy chủ tại Vietnix. Đảm bảo các dữ liệu này không chứa phần mềm phá hoại và tuân thủ các quy định của pháp luật về quyền sở hữu công nghiệp, bản quyền, bí mật quốc gia, an ninh, văn hoá. Không sử dụng dịch vụ của Vietnix cung cấp cho mục đích: tổ chức đánh bạc, cá độ, lô đề, hack, tấn công phá hoại (DDoS), lừa đảo, đào coin, Spam Mail (Spam Email trong trường hợp này được hiểu là thư rác điện tử theo quy định tại Nghị định 90/2008/NĐ-CP hoặc bất kỳ văn bản nào thay thế Nghị định 90/2008/NĐ-CP sau này). Nếu vi phạm điều khoản này, khách hàng sẽ hoàn toàn tự mình chịu trách nhiệm trước pháp luật mà không liên quan đến chúng tôi.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.2   Khách hàng cần lưu giữ các thông tin nhận biết, mật khẩu hay những thông tin khác liên quan đến tài khoản của dịch vụ hoặc tài khoản quản lý khách hàng một cách an toàn. Trong trường hợp phát hiện các hình thức truy cập trái phép sử dụng tài khoản của bạn hoặc các sơ hở về bảo mật như mất mát, đánh cắp hoặc để lộ thông tin về mật khẩu và các thông tin khác cần báo cho chúng tôi ngay lập tức.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.3   Khách hàng có trách nhiệm tự bảo quản dữ liệu và mã nguồn trên máy chủ của Vietnix. Chúng tôi không chịu bất cứ trách nhiệm nào trong mọi trường hợp liên quan tới dữ liệu của người dùng.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.4   Khách hàng có trách nhiệm bảo mật quyền truy nhập từ xa do Vietnix cấp, đồng thời khách hàng phải chịu trách nhiệm trước pháp luật nếu cố ý để quyền truy nhập từ xa bị bên thứ ba lợi dụng thực hiện các hành động phạm pháp.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.5   Khách hàng có trách nhiệm ký xác nhận biên bản nghiệm thu hoặc bản ghi nhớ công việc khi chúng tôi hoàn tất công việc tại các phụ lục đính kèm hợp đồng hợp tác dịch vụ. Trong vòng 05 (năm) ngày làm việc, kể từ ngày chúng tôi có văn bản đề nghị nghiệm thu mà khách hàng không xác nhận nghiệm thu thì phụ lục coi như mặc nhiên được nghiệm thu.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.6   Thông báo cho chúng tôi về sự thay đổi tên, địa chỉ công ty, địa chỉ gửi hóa đơn thanh toán, số tài khoản, thời gian tạm ngưng dịch vụ (nếu có) trước ít nhất 15 (mười lăm) ngày làm việc.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.7   Khách hàng cam kết thực hiện đúng quyền và nghĩa vụ được ký kết tại hợp đồng dịch vụ và các phụ lục kèm theo.</p><p style=\"border: 0px solid rgb(228, 230, 234); --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-scroll-snap-strictness:proximity; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgb(59 130 246/0.5); --tw-ring-offset-shadow:0 0 transparent; --tw-ring-shadow:0 0 transparent; --tw-shadow:0 0 transparent; --tw-shadow-colored:0 0 transparent; margin-right: 0px; margin-bottom: 18px; margin-left: 0px; word-break: break-word; padding-top: 6px; line-height: 1.8; color: rgb(17, 17, 17); font-family: Roboto, sans-serif;\">1.8   Khách hàng có quyền tạm ngưng sử dụng dịch vụ nếu chúng tôi vi phạm hợp đồng.</p>'),
(33, 'expire', '30'),
(34, 'token_telegram', '5099279924:AAFYHaKQeLnnLeBZISa-EtRV5qJ6I3fHNaQ'),
(35, 'token_bot', '5700927756:AAGXCTdWLcHoryA87RDSgGSkwbPXwQeES28'),
(36, 'keywords', 'Enigma admin is super flexible, powerful, clean & modern responsive tailwind admin template with unlimited possibilities.'),
(37, 'partner_id', '21245721762'),
(38, 'partner_key', '3c001ae3b8328fb3df6de1a4d4b3c3df');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_vps`
--

CREATE TABLE `order_vps` (
  `id` int(11) NOT NULL,
  `ip_vm` text CHARACTER SET utf8mb4,
  `email` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `account` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `money` int(50) DEFAULT NULL,
  `dichvu` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ip_country` text CHARACTER SET utf8mb4,
  `window_os` text CHARACTER SET utf8mb4,
  `ram` int(50) DEFAULT NULL,
  `cpu` int(50) DEFAULT NULL,
  `storage` int(50) DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_runtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `order_vps`
--

INSERT INTO `order_vps` (`id`, `ip_vm`, `email`, `username`, `account`, `password`, `money`, `dichvu`, `ip_country`, `window_os`, `ram`, `cpu`, `storage`, `note`, `create_time`, `end_time`, `update_time`, `update_runtime`, `status`) VALUES
(1, '127.0.0.1:28774', NULL, 'nguyenquocanhdz', 'nguyenquocanhdz1', 'FASFSADA', 134000, 'CLOUD VPS BUSSINESS', 'Hồ Chí Minh', 'Windows Server 2012', 1, 1, 30, 'HI', '2023-02-06 02:48:52', '2023-03-06 02:48:52', '2023-02-06 04:14:27', '2023-02-06 05:51:50', '1'),
(2, '127.0.0.1:2874', NULL, 'hoangkhoi', 'test', 'pass', 134000, 'CLOUD VPS BUSSINESS', 'Hà Nội', 'Windows Server 2012', 1, 1, 30, 'hI', '2023-02-06 03:25:19', '2023-03-06 03:25:19', '2023-02-06 04:13:28', '2023-02-06 05:51:50', '1'),
(3, NULL, NULL, 'nguyenquocanhdz', NULL, NULL, 107200, 'CLOUD VPS BUSSINESS', 'Ngẫu Nhiên', 'Ngẫu nhiên', 1, 1, 30, '', '2023-02-06 16:13:32', '2023-03-06 16:13:32', '2023-02-06 16:13:32', '2023-02-06 16:13:32', '0'),
(4, NULL, NULL, 'nguyenquocanhdz', NULL, NULL, 107200, 'CLOUD VPS BUSSINESS', 'Ngẫu Nhiên', 'Ngẫu nhiên', 1, 1, 30, '', '2023-02-06 16:18:10', '2023-03-06 16:18:10', '2023-02-06 16:18:10', '2023-02-06 16:18:10', '0'),
(5, 'a', NULL, 'nguyenquocanhdz', 'a', 'a', 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, 'a', '2023-02-07 10:36:43', '2023-03-07 10:36:43', '2023-02-07 13:26:05', '2023-02-07 10:36:43', '1'),
(6, '127.0.0.1:28774', NULL, 'nguyenquocanhdz', 'nguyenquocanhdz1', 'anhanh123', 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-08 06:00:11', '2023-03-08 06:01:00', '2023-02-08 06:07:12', '2023-02-08 06:00:11', '1'),
(7, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-08 06:29:52', '0000-00-00 00:00:00', '2023-02-08 06:29:52', '2023-02-08 06:29:52', '0'),
(8, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-08 18:58:37', '0000-00-00 00:00:00', '2023-02-08 18:58:37', '2023-02-08 18:58:37', '0'),
(9, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 15:36:35', '0000-00-00 00:00:00', '2023-02-10 15:36:35', '2023-02-10 15:36:35', '0'),
(10, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 48000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 15:40:37', '2023-02-10 15:40:37', '2023-02-10 15:40:37', '2023-02-10 15:40:37', '0'),
(11, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 15:42:38', '2023-02-10 15:42:38', '2023-02-10 15:42:38', '2023-02-10 15:42:38', '0'),
(12, '127.0.0.1:28774', 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', 'nguyenquocanhdz1', 'anhanh123', 48000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, 'he', '2023-02-10 15:43:53', '2023-03-10 15:44:00', '2023-02-10 15:44:41', '2023-02-10 15:43:53', '1'),
(13, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 48000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, 'gi', '2023-02-10 19:23:31', '2023-02-10 19:23:31', '2023-02-10 19:23:31', '2023-02-10 19:23:31', '0'),
(14, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 600000, 'CLOUD B', 'Hồ Chí Minh', 'Windows Server 2012', 2, 2, 20, 's', '2023-02-10 19:26:48', '2023-02-10 19:26:48', '2023-02-10 19:26:48', '2023-02-10 19:26:48', '0'),
(15, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 19:29:27', '2023-02-10 19:29:27', '2023-02-10 19:29:27', '2023-02-10 19:29:27', '0'),
(16, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 19:32:45', '2023-02-10 19:32:45', '2023-02-10 19:32:45', '2023-02-10 19:32:45', '0'),
(17, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 19:41:37', '2023-02-10 19:41:37', '2023-02-10 19:41:37', '2023-02-10 19:41:37', '0'),
(18, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 19:44:19', '2023-02-10 19:44:19', '2023-02-10 19:44:19', '2023-02-10 19:44:19', '0'),
(19, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 48000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-10 19:45:41', '2023-02-10 19:45:41', '2023-02-10 19:45:41', '2023-02-10 19:45:41', '0'),
(20, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 48000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, 'hi', '2023-02-10 20:01:06', '2023-02-10 20:01:06', '2023-02-10 20:01:06', '2023-02-10 20:01:06', '0'),
(21, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, 'hi', '2023-02-10 20:02:22', '2023-02-10 20:02:22', '2023-02-10 20:02:22', '2023-02-10 20:02:22', '0'),
(22, NULL, 'quocanhnguyen017@gmail.com', 'nguyenquocanhdz', NULL, NULL, 16000, 'CLOUD A', 'US', 'LINUX', 1, 1, 12, '', '2023-02-13 17:50:04', '2023-02-13 17:50:04', '2023-02-13 17:50:04', '2023-02-13 17:50:04', '0');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `message` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `answer` longtext CHARACTER SET utf8mb4,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `question`
--

INSERT INTO `question` (`id`, `message`, `answer`, `update_time`, `status`) VALUES
(1, 'Chào bạn', 'Xin chào mình có giúp gì cho bạn ạ ! Mình là ChatBot được viết bởi Nguyễn Quốc Anh', '2023-02-16 02:59:43', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_telegram` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `otp` int(50) DEFAULT NULL,
  `token` longtext CHARACTER SET utf8mb4,
  `chietkhau` int(11) NOT NULL DEFAULT '0',
  `sovongquay` int(11) NOT NULL DEFAULT '0',
  `money` int(50) NOT NULL DEFAULT '0',
  `total_money` int(50) NOT NULL DEFAULT '0',
  `level` varchar(25) CHARACTER SET utf8mb4 DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `banned` int(10) NOT NULL DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `HTTP_USER_AGENT` longtext CHARACTER SET utf8mb4
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `id_telegram`, `username`, `password`, `phone`, `email`, `otp`, `token`, `chietkhau`, `sovongquay`, `money`, `total_money`, `level`, `create_time`, `banned`, `ip`, `HTTP_USER_AGENT`) VALUES
(1, '1364926983', 'nguyenquocanhdz', 'anhanh123', '0397426841', 'quocanhnguyen017@gmail.com', 0, 'hFklQwmCYRgKZyVsDLrjIvJzGUaxquWXtAONcoTSifBMbpnHeEdP', 20, 0, 4119600, 56050000, 'admin', '2023-02-03 07:54:29', 0, '42.116.181.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(2, NULL, 'nguyenquocanhdz1', 'anhanh1234', '0397426842', 'music.quocanhnguyen017@gmail.com', 0, 'ZmOEoHexrPFTDhaVStGMvisYWupwgfcCNIKBzlyJQdLUXRAnqbkj', 0, 0, 1, 0, NULL, '2023-02-03 08:38:34', 0, '42.116.181.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(3, NULL, 'hoangkhoi', 'hoangkhoi', '0945946021', 'hoangkhoi@gmail.com', 0, 'zvMBjTlKgZGhiskoEpeVJISLfXWnHDCaAFRbNUtxuwmYPcyQdrqO', 0, 0, 4598000, 5000000, NULL, '2023-02-03 10:51:22', 0, '183.81.49.220', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 LightSpeed [FBAN/MessengerLiteForiOS;FBAV/393.0.0.22.91;FBBV/441169027;FBDV/iPhone12,1;FBMD/iPhone;FBSN/iOS;FBSV/16.2;FBSS/2;FBCR/;FBID/phone;FBLC/vi;FBOP/0]'),
(4, NULL, 'nguyenanhz', 'anhanh1234', '0397426841', 'music.quocanhnguyen017@gmail.com', 0, 'waYsZSlyhHdGvDKfBLijbqUJkImXCMTocAQpPNnzuFEWRVrgxetO', 0, 0, 0, 0, NULL, '2023-02-05 16:43:20', 0, '42.116.181.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(5, NULL, 'hehehehe', 'hehehehe', 'hehehehe', 'hehehehe', 0, 'auZoLgCcORAHkqybeUpVGDhNQTiJIdmBlwKEfnSXPrWMzFtxjsYv', 0, 0, 0, 0, NULL, '2023-02-05 16:47:49', 0, '27.70.224.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(6, NULL, 'nguyenquocanhz1', 'anhanh123', '0397426841', 'quocanhnguyen748@gmail.com', 0, 'cGFLUCBSDpzyseXmKqhlrOnTowgkjfEuJWMPtaAQbxYHvINVZdiR', 0, 0, 0, 0, NULL, '2023-02-06 06:46:56', 0, '42.116.181.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `window_os`
--

CREATE TABLE `window_os` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4,
  `money` int(50) NOT NULL DEFAULT '0',
  `display` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `window_os`
--

INSERT INTO `window_os` (`id`, `name`, `description`, `money`, `display`) VALUES
(1, 'Windows Server 2012', NULL, 0, 'SHOW'),
(2, 'Windows Server 2016', NULL, 0, 'SHOW'),
(3, 'Windows Server 2019', NULL, 0, 'SHOW'),
(5, 'Window Server 2023', '', 0, 'SHOW');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `api_key_tool`
--
ALTER TABLE `api_key_tool`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `bank_auto`
--
ALTER TABLE `bank_auto`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `banquyen`
--
ALTER TABLE `banquyen`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `cloud`
--
ALTER TABLE `cloud`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `dongtien`
--
ALTER TABLE `dongtien`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `napthe`
--
ALTER TABLE `napthe`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `order_vps`
--
ALTER TABLE `order_vps`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `window_os`
--
ALTER TABLE `window_os`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `api_key_tool`
--
ALTER TABLE `api_key_tool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `bank_auto`
--
ALTER TABLE `bank_auto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `banquyen`
--
ALTER TABLE `banquyen`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT cho bảng `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `cloud`
--
ALTER TABLE `cloud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `dongtien`
--
ALTER TABLE `dongtien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `napthe`
--
ALTER TABLE `napthe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT cho bảng `order_vps`
--
ALTER TABLE `order_vps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT cho bảng `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `window_os`
--
ALTER TABLE `window_os`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
